# ODM2-Admin Docker Application

To deploy this application on Docker simply navigate to current directory `docker-deploy`.

Execute docker-compose to deploy the application:

```bash
docker-compose up
```

The default login to ODM2-Admin:

Username: admin
Password: odm2admin

